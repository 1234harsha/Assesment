﻿using BookServiceApi.Model;

namespace BookServiceApi.Repository
{
    public interface IBookRepository
    {
        void AddBook(Book book);
        List<Book> GetAllBooks();

        List<Book> GetBooksByAuthor(string Autor);

        List<Book> GetBooksByLang(string lang);

        List<Book> GetBooksByYear(int year);

        void  EditBook(Book book);

        void DeleteBook(int bookId);

        void GetBooksByBookName(string name);

        void GetBooksById(int id);
    }
}
