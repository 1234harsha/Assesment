﻿using BookServiceApi.Model;
using BookServiceApi.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookServiceApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookRepository bookRepository;
        public BookController()
        {
            bookRepository = new BookRepository();
        }
        //end points
        [HttpPost("AddBook")] // to add new book
        public IActionResult Add(Book book)
        {
            try
            {
                bookRepository.AddBook(book);
                return StatusCode(200, book);
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }
        [HttpGet, Route("GetAllBooks")]  // to get all books
         public IActionResult GetAll()
        {
            try
            {
                List<Book> books = bookRepository.GetAllBooks();
                return StatusCode(200, books);
            }
            catch (Exception)
            {

                throw;
            }

        }

        [HttpGet("getBookByAuthor/{author}")] // to get all books by author
        public IActionResult GetBookByAuthor(string author)
        {
            try
            {
                return StatusCode(200, bookRepository.GetBooksByAuthor(author));
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }
       
        [HttpGet("getBookByLanguage/{lang}")]  // to get all books by language
        public IActionResult GetBookByLanguage(string lang)
        {
            try
            {
                return StatusCode(200, bookRepository.GetBooksByLang(lang));
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }

        [HttpGet("getBookbyyear/{year}")]
        public IActionResult GetBookByYear(int year)
        {
            try
            {
                return StatusCode(200, bookRepository.GetBooksByYear(year));

            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }

        
        [HttpPut("EditBook")] // Upadte book
        public IActionResult EditBook(Book book)
        {
            try
            {
                bookRepository.EditBook(book);
                return StatusCode(200, book);

            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }

        [HttpDelete("DeleteBook/{id}")] // delete book
        public IActionResult Delete(int id)
        {
            try
            {
                bookRepository.DeleteBook(id);
                return StatusCode(200, "Book deleted");
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }
        [HttpDelete("getbyBookId/{id}")] // get book by id
        public IActionResult getbybookid(int id)
        {
            try
            {
                bookRepository.GetBooksById(id);
                return StatusCode(200);
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }

        [HttpDelete("getbyBookName/{name}")] // get book by id
        public IActionResult getbybookname(string name)
        {
            try
            {
                bookRepository.GetBooksByBookName(name);
                return StatusCode(200);
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }



    }
}
